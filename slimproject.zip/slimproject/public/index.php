<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

require '../vendor/autoload.php';

$app = new \Slim\App;

require_once('../app/api/location.php');

/*
*
*Database connection
*
*/
//include 'db_connection.php';
// 
//$conn = OpenCon();
// 
//echo "Connected Successfully";
// 
//CloseCon($conn);


$app->run();
 
?>