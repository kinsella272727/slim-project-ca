<?php 

//Display all records
    $app->get('/api/locations', function() {
       
        require_once('db_connection.php');
        
        $query = "select * from location order by locationId";
        
        $result = $mysqli->query($query);
        
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        if (isset($data)) {
            header('Content-Type: application/json');
            echo json_encode($data);
        }
});
//Display single row
    $app->get('/api/chipperLocations/{id}', function($req) {
       
        require_once('db_connection.php');
        
        $id = $req->getAttribute('id');
        
        $query = "select * from chipper_location WHERE chipperId = $id";
        
        
        $result = $mysqli->query($query);
    
        
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
                
        foreach ($data as &$location) {
            
             
            $query = "select * from location WHERE locationId = " . $location["locationId"]; 
                
            $result = $mysqli->query($query);
            
            $locations[] = $result->fetch_assoc();
        }
        
        
        
        if (isset($data)) {
            header('Content-Type: application/json');
            echo json_encode($locations);
        }
});

$app->post('/api/addFavourite', function($request) {
    
//    $my_name = $_POST['my_name'];
//    echo "hello ".$my_name;
    
    
    
    
    $data = $request->getParsedBody();
    $favs = [];
    $favs['userId'] = filter_var($data['userId'], FILTER_SANITIZE_STRING);
    $favs['chipperId'] = filter_var($data['chipperId'], FILTER_SANITIZE_STRING);
    $favs['locationId'] = filter_var($data['locationId'], FILTER_SANITIZE_STRING);
        
    
    require_once('db_connection.php');
    
    $query = "INSERT INTO 'favourite' ('userId', 'chipperId', 'locationId') VALUES ('".$favs['userId']."', '". $favs['chipperId']."', '".$favs['locationId']."')";
    
    $stmt = $mysqli->prepare($query);
//    $stmt->bind_param("userId", $favs['userId']);
//    $stmt->bind_param("chipperId", $favs['chipperId']);
//    $stmt->bind_param("locationId", $favs['locationId']);

        
    $stmt->execute();

});


    $app->get('/api/favourites/{id}', function($req) {
        
//        $data = $request->getParsedBody();
        $userID = filter_var($req->getAttribute('id'), FILTER_SANITIZE_STRING);
       
        require_once('db_connection.php');
                
        $query = "select * from favourite WHERE userId = $userID";
        
        $result = $mysqli->query($query);
        
        
//        echo $result;
        
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        if (isset($data)) {
            header('Content-Type: application/json');
            echo json_encode($data);
        }
        
});



    