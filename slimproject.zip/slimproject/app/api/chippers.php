<?php 

//Display all records
    $app->get('/api/chippers', function() {
       
        require_once('db_connection.php');
        
        $query = "select * from chippers order by chipperId";
        
        $result = $mysqli->query($query);
        
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        
        if (isset($data)) {
            header('Content-Type: application/json');
            echo json_encode($data);
        }
        
});
?>